-- AI Meeting Coordinator demo seed
-- Times are stored as timestamptz with an explicit Asia/Seoul offset (+09:00).
-- This file intentionally stores busy ranges only, never source calendar titles.

begin;

-- ---------------------------------------------------------------------------
-- Users, profiles, preferences, and Google Calendar connection metadata
-- ---------------------------------------------------------------------------

insert into auth.users (
  instance_id, id, aud, role, email, encrypted_password,
  email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
  created_at, updated_at
)
values
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000001', 'authenticated', 'authenticated', 'minjun.kim@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"김민준"}', now(), now()),
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000002', 'authenticated', 'authenticated', 'seoyeon.lee@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"이서연"}', now(), now()),
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000003', 'authenticated', 'authenticated', 'jihoon.park@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"박지훈"}', now(), now()),
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000004', 'authenticated', 'authenticated', 'yujin.choi@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"최유진"}', now(), now()),
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000005', 'authenticated', 'authenticated', 'haneul.jeong@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"정하늘"}', now(), now()),
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000006', 'authenticated', 'authenticated', 'jimin.han@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"한지민"}', now(), now()),
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000007', 'authenticated', 'authenticated', 'dohyun.yoon@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"윤도현"}', now(), now()),
  ('00000000-0000-0000-0000-000000000000', '10000000-0000-0000-0000-000000000008', 'authenticated', 'authenticated', 'subin.song@example.com', crypt('Demo1234!', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{"full_name":"송수빈"}', now(), now())
on conflict (id) do update
set email = excluded.email,
    raw_user_meta_data = excluded.raw_user_meta_data,
    updated_at = now();

-- The auth trigger creates these rows. Upserts also make this seed usable when
-- the trigger has already run for the deterministic demo UUIDs.
insert into public.profiles (id, email, display_name, timezone)
values
  ('10000000-0000-0000-0000-000000000001', 'minjun.kim@example.com', '김민준', 'Asia/Seoul'),
  ('10000000-0000-0000-0000-000000000002', 'seoyeon.lee@example.com', '이서연', 'Asia/Seoul'),
  ('10000000-0000-0000-0000-000000000003', 'jihoon.park@example.com', '박지훈', 'Asia/Seoul'),
  ('10000000-0000-0000-0000-000000000004', 'yujin.choi@example.com', '최유진', 'Asia/Seoul'),
  ('10000000-0000-0000-0000-000000000005', 'haneul.jeong@example.com', '정하늘', 'Asia/Seoul'),
  ('10000000-0000-0000-0000-000000000006', 'jimin.han@example.com', '한지민', 'Asia/Seoul'),
  ('10000000-0000-0000-0000-000000000007', 'dohyun.yoon@example.com', '윤도현', 'Asia/Seoul'),
  ('10000000-0000-0000-0000-000000000008', 'subin.song@example.com', '송수빈', 'Asia/Seoul')
on conflict (id) do update
set email = excluded.email, display_name = excluded.display_name,
    timezone = excluded.timezone, updated_at = now();

insert into public.user_preferences (
  user_id, preferred_period, workday_start, workday_end, max_meetings_per_day
)
values
  ('10000000-0000-0000-0000-000000000001', 'morning',   '09:00', '18:00', 4),
  ('10000000-0000-0000-0000-000000000002', 'afternoon', '10:00', '19:00', 5),
  ('10000000-0000-0000-0000-000000000003', 'evening',   '11:00', '21:00', 3),
  ('10000000-0000-0000-0000-000000000004', 'any',       '09:00', '18:00', 4),
  ('10000000-0000-0000-0000-000000000005', 'morning',   '08:00', '17:00', 3),
  ('10000000-0000-0000-0000-000000000006', 'afternoon', '10:00', '19:00', 4),
  ('10000000-0000-0000-0000-000000000007', 'evening',   '12:00', '21:00', 2),
  ('10000000-0000-0000-0000-000000000008', 'any',       '09:00', '20:00', 5)
on conflict (user_id) do update
set preferred_period = excluded.preferred_period,
    workday_start = excluded.workday_start,
    workday_end = excluded.workday_end,
    max_meetings_per_day = excluded.max_meetings_per_day,
    updated_at = now();

insert into public.calendar_connections (
  id, user_id, provider, provider_account_id, granted_scopes,
  calendar_ids, sync_status, last_synced_at
)
select
  ('20000000-0000-0000-0000-' || right(u.id::text, 12))::uuid,
  u.id, 'google', 'demo-' || u.id::text,
  array['https://www.googleapis.com/auth/calendar.readonly'],
  '["primary"]'::jsonb, 'connected', '2026-08-16T22:00:00+09:00'::timestamptz
from (values
  ('10000000-0000-0000-0000-000000000001'::uuid),
  ('10000000-0000-0000-0000-000000000002'::uuid),
  ('10000000-0000-0000-0000-000000000003'::uuid),
  ('10000000-0000-0000-0000-000000000004'::uuid),
  ('10000000-0000-0000-0000-000000000005'::uuid),
  ('10000000-0000-0000-0000-000000000006'::uuid),
  ('10000000-0000-0000-0000-000000000007'::uuid),
  ('10000000-0000-0000-0000-000000000008'::uuid)
) as u(id)
on conflict (user_id) do update
set provider_account_id = excluded.provider_account_id,
    granted_scopes = excluded.granted_scopes,
    calendar_ids = excluded.calendar_ids,
    sync_status = excluded.sync_status,
    last_synced_at = excluded.last_synced_at;

-- ---------------------------------------------------------------------------
-- Groups and memberships
-- ---------------------------------------------------------------------------

insert into public.team_groups (
  id, owner_user_id, name, description, default_meeting_importance
)
values
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'AI 프로젝트팀', '해커톤 AI 일정 조율 프로젝트', 5),
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000002', '캡스톤 스터디', '캡스톤 발표와 결과물 준비', 4),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000003', '동아리 운영진', '동아리 행사 및 운영 회의', 4),
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000004', '친구 모임', '주말 친목 모임', 2)
on conflict (id) do update
set owner_user_id = excluded.owner_user_id, name = excluded.name,
    description = excluded.description,
    default_meeting_importance = excluded.default_meeting_importance,
    updated_at = now();

insert into public.group_members (group_id, user_id, role, personal_importance)
values
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'owner',  5),
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000002', 'member', 4),
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000003', 'member', 5),
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000004', 'member', 3),
  ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000005', 'member', 4),
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000002', 'owner',  5),
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000001', 'member', 3),
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000004', 'member', 4),
  ('30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000006', 'member', 5),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000003', 'owner',  5),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000002', 'member', 3),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000005', 'member', 4),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000006', 'member', 4),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000007', 'member', 5),
  ('30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000008', 'member', 2),
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000004', 'owner',  5),
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000001', 'member', 2),
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000003', 'member', 3),
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000007', 'member', 4),
  ('30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000008', 'member', 5)
on conflict (group_id, user_id) do update
set role = excluded.role, personal_importance = excluded.personal_importance,
    updated_at = now();

-- ---------------------------------------------------------------------------
-- Calendar busy blocks, 2026-08-17 through 2026-08-30
-- ---------------------------------------------------------------------------

with busy(user_no, event_no, starts_at, ends_at, is_all_day) as (values
  (1, 1, '2026-08-17T09:00:00+09:00'::timestamptz, '2026-08-17T11:00:00+09:00'::timestamptz, false),
  (1, 2, '2026-08-19T18:30:00+09:00', '2026-08-19T20:00:00+09:00', false),
  (1, 3, '2026-08-20T19:00:00+09:00', '2026-08-20T20:00:00+09:00', false),
  (1, 4, '2026-08-22T10:00:00+09:00', '2026-08-22T12:00:00+09:00', false),
  (1, 5, '2026-08-25T14:00:00+09:00', '2026-08-25T16:00:00+09:00', false),
  (1, 6, '2026-08-28T18:00:00+09:00', '2026-08-28T20:00:00+09:00', false),
  (2, 1, '2026-08-18T10:00:00+09:00', '2026-08-18T12:00:00+09:00', false),
  (2, 2, '2026-08-20T18:00:00+09:00', '2026-08-20T19:00:00+09:00', false),
  (2, 3, '2026-08-24T09:00:00+09:00', '2026-08-24T11:00:00+09:00', false),
  (2, 4, '2026-08-25T19:00:00+09:00', '2026-08-25T21:00:00+09:00', false),
  (2, 5, '2026-08-27T13:00:00+09:00', '2026-08-27T15:00:00+09:00', false),
  (2, 6, '2026-08-30T00:00:00+09:00', '2026-08-31T00:00:00+09:00', true),
  (3, 1, '2026-08-19T14:30:00+09:00', '2026-08-19T16:30:00+09:00', false),
  (3, 2, '2026-08-21T09:00:00+09:00', '2026-08-21T11:00:00+09:00', false),
  (3, 3, '2026-08-22T18:00:00+09:00', '2026-08-22T19:00:00+09:00', false),
  (3, 4, '2026-08-24T17:00:00+09:00', '2026-08-24T19:00:00+09:00', false),
  (3, 5, '2026-08-26T12:00:00+09:00', '2026-08-26T14:00:00+09:00', false),
  (3, 6, '2026-08-29T15:00:00+09:00', '2026-08-29T17:00:00+09:00', false),
  (4, 1, '2026-08-19T15:00:00+09:00', '2026-08-19T17:00:00+09:00', false),
  (4, 2, '2026-08-23T13:00:00+09:00', '2026-08-23T15:00:00+09:00', false),
  (4, 3, '2026-08-25T10:00:00+09:00', '2026-08-25T12:00:00+09:00', false),
  (4, 4, '2026-08-27T18:00:00+09:00', '2026-08-27T20:00:00+09:00', false),
  (4, 5, '2026-08-29T13:00:00+09:00', '2026-08-29T15:00:00+09:00', false),
  (5, 1, '2026-08-18T16:00:00+09:00', '2026-08-18T18:00:00+09:00', false),
  (5, 2, '2026-08-21T19:00:00+09:00', '2026-08-21T20:00:00+09:00', false),
  (5, 3, '2026-08-24T09:30:00+09:00', '2026-08-24T10:30:00+09:00', false),
  (5, 4, '2026-08-26T18:00:00+09:00', '2026-08-26T20:00:00+09:00', false),
  (5, 5, '2026-08-28T14:00:00+09:00', '2026-08-28T16:00:00+09:00', false),
  (5, 6, '2026-08-29T00:00:00+09:00', '2026-08-30T00:00:00+09:00', true),
  (6, 1, '2026-08-20T18:00:00+09:00', '2026-08-20T19:00:00+09:00', false),
  (6, 2, '2026-08-23T16:00:00+09:00', '2026-08-23T18:00:00+09:00', false),
  (6, 3, '2026-08-24T11:00:00+09:00', '2026-08-24T12:30:00+09:00', false),
  (6, 4, '2026-08-26T19:30:00+09:00', '2026-08-26T21:00:00+09:00', false),
  (6, 5, '2026-08-27T09:00:00+09:00', '2026-08-27T11:00:00+09:00', false),
  (6, 6, '2026-08-29T13:00:00+09:00', '2026-08-29T14:30:00+09:00', false),
  (7, 1, '2026-08-21T18:00:00+09:00', '2026-08-21T19:00:00+09:00', false),
  (7, 2, '2026-08-22T19:00:00+09:00', '2026-08-22T21:00:00+09:00', false),
  (7, 3, '2026-08-24T14:00:00+09:00', '2026-08-24T16:00:00+09:00', false),
  (7, 4, '2026-08-26T18:00:00+09:00', '2026-08-26T19:30:00+09:00', false),
  (7, 5, '2026-08-28T20:00:00+09:00', '2026-08-28T22:00:00+09:00', false),
  (7, 6, '2026-08-29T10:00:00+09:00', '2026-08-29T12:00:00+09:00', false),
  (8, 1, '2026-08-20T20:00:00+09:00', '2026-08-20T21:00:00+09:00', false),
  (8, 2, '2026-08-22T18:00:00+09:00', '2026-08-22T19:00:00+09:00', false),
  (8, 3, '2026-08-23T10:00:00+09:00', '2026-08-23T12:00:00+09:00', false),
  (8, 4, '2026-08-24T15:00:00+09:00', '2026-08-24T17:00:00+09:00', false),
  (8, 5, '2026-08-27T19:00:00+09:00', '2026-08-27T21:00:00+09:00', false),
  (8, 6, '2026-08-28T00:00:00+09:00', '2026-08-29T00:00:00+09:00', true)
)
insert into public.calendar_busy_blocks (
  id, calendar_connection_id, user_id, source_event_id,
  starts_at, ends_at, is_all_day
)
select
  ('40000000-0000-0000-' || lpad(user_no::text, 4, '0') || '-' || lpad(event_no::text, 12, '0'))::uuid,
  ('20000000-0000-0000-0000-' || lpad(user_no::text, 12, '0'))::uuid,
  ('10000000-0000-0000-0000-' || lpad(user_no::text, 12, '0'))::uuid,
  'demo-u' || user_no || '-busy-' || event_no,
  starts_at, ends_at, is_all_day
from busy
on conflict (calendar_connection_id, source_event_id) do update
set starts_at = excluded.starts_at, ends_at = excluded.ends_at,
    is_all_day = excluded.is_all_day, updated_at = now();

-- ---------------------------------------------------------------------------
-- Meeting requests and requested participants
-- ---------------------------------------------------------------------------

insert into public.meeting_requests (
  id, group_id, requested_by, title, raw_request, ai_constraints,
  meeting_kind, meeting_importance, duration_minutes,
  date_range_start, date_range_end, preferred_period, status
)
values
  ('50000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'AI 데모 기능 점검', '8월 18일이나 19일 오후에 한 시간 데모 점검', '{"goal":"all_participants"}', 'project', 5, 60, '2026-08-18', '2026-08-19', 'afternoon', 'confirmed'),
  ('50000000-0000-0000-0000-000000000002', '30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000003', '발표 자료 최종 검토', '24일이나 25일 오전에 90분 발표 자료 검토', '{"goal":"required_participants"}', 'review', 4, 90, '2026-08-24', '2026-08-25', 'morning', 'parsed'),
  ('50000000-0000-0000-0000-000000000003', '30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000002', '캡스톤 주간 스터디', '20일 저녁에 전원이 가능한 한 시간', '{"goal":"all_required"}', 'study', 4, 60, '2026-08-20', '2026-08-20', 'evening', 'confirmed'),
  ('50000000-0000-0000-0000-000000000004', '30000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000006', '중간 결과 리뷰', '29일 오후에 두 시간 결과 리뷰', '{"goal":"weekend_review"}', 'review', 4, 120, '2026-08-29', '2026-08-29', 'afternoon', 'ranked'),
  ('50000000-0000-0000-0000-000000000005', '30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000003', '운영진 행사 준비 회의', '21일 저녁 공정한 시간으로 한 시간', '{"goal":"fairness","consider_attendance":true}', 'operations', 5, 60, '2026-08-21', '2026-08-21', 'evening', 'ranked'),
  ('50000000-0000-0000-0000-000000000006', '30000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000007', '다음 달 운영 계획', '26일이나 27일 저녁 90분 운영 계획', '{"goal":"maximize_required"}', 'planning', 4, 90, '2026-08-26', '2026-08-27', 'evening', 'ranked'),
  ('50000000-0000-0000-0000-000000000007', '30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000004', '주말 모임 일정 정하기', '22일이나 23일 저녁 한 시간', '{"goal":"required_then_total"}', 'social', 2, 60, '2026-08-22', '2026-08-23', 'evening', 'ranked'),
  ('50000000-0000-0000-0000-000000000008', '30000000-0000-0000-0000-000000000004', '10000000-0000-0000-0000-000000000008', '저녁 식사 장소 회의', '28일이나 29일 저녁 한 시간', '{}', 'social', 2, 60, '2026-08-28', '2026-08-29', 'evening', 'draft')
on conflict (id) do update
set group_id = excluded.group_id, requested_by = excluded.requested_by,
    title = excluded.title, raw_request = excluded.raw_request,
    ai_constraints = excluded.ai_constraints,
    meeting_kind = excluded.meeting_kind,
    meeting_importance = excluded.meeting_importance,
    duration_minutes = excluded.duration_minutes,
    date_range_start = excluded.date_range_start,
    date_range_end = excluded.date_range_end,
    preferred_period = excluded.preferred_period,
    status = excluded.status, updated_at = now();

with participant_map(request_no, user_no, is_required) as (values
  (1,1,true),(1,2,true),(1,3,true),(1,4,false),(1,5,false),
  (2,1,true),(2,2,false),(2,3,true),(2,4,false),(2,5,true),
  (3,1,true),(3,2,true),(3,4,true),(3,6,true),
  (4,1,false),(4,2,true),(4,4,true),(4,6,true),
  (5,2,false),(5,3,true),(5,5,false),(5,6,true),(5,7,true),(5,8,false),
  (6,2,false),(6,3,true),(6,5,true),(6,6,false),(6,7,true),(6,8,false),
  (7,1,false),(7,3,false),(7,4,true),(7,7,true),(7,8,false),
  (8,1,false),(8,3,false),(8,4,true),(8,7,false),(8,8,true)
)
insert into public.meeting_request_participants (request_id, user_id, is_required)
select
  ('50000000-0000-0000-0000-' || lpad(request_no::text, 12, '0'))::uuid,
  ('10000000-0000-0000-0000-' || lpad(user_no::text, 12, '0'))::uuid,
  is_required
from participant_map
on conflict (request_id, user_id) do update
set is_required = excluded.is_required;

-- ---------------------------------------------------------------------------
-- Ranked candidates. R2 remains parsed and R8 remains draft, so neither has
-- persisted candidates yet.
-- ---------------------------------------------------------------------------

insert into public.schedule_candidates (
  id, request_id, starts_at, ends_at, rank, score, score_breakdown,
  available_count, required_available_count
)
values
  ('60000000-0000-0001-0000-000000000001', '50000000-0000-0000-0000-000000000001', '2026-08-18T14:00:00+09:00', '2026-08-18T15:00:00+09:00', 1, 98, '{"availability":100,"preference":95}', 5, 3),
  ('60000000-0000-0001-0000-000000000002', '50000000-0000-0000-0000-000000000001', '2026-08-18T16:00:00+09:00', '2026-08-18T17:00:00+09:00', 2, 84, '{"availability":80,"required":100}', 4, 3),
  ('60000000-0000-0001-0000-000000000003', '50000000-0000-0000-0000-000000000001', '2026-08-19T15:00:00+09:00', '2026-08-19T16:00:00+09:00', 3, 61, '{"availability":60,"required":67}', 3, 2),
  ('60000000-0000-0003-0000-000000000001', '50000000-0000-0000-0000-000000000003', '2026-08-20T20:00:00+09:00', '2026-08-20T21:00:00+09:00', 1, 97, '{"availability":100,"required":100}', 4, 4),
  ('60000000-0000-0003-0000-000000000002', '50000000-0000-0000-0000-000000000003', '2026-08-20T19:00:00+09:00', '2026-08-20T20:00:00+09:00', 2, 78, '{"availability":75,"required":75}', 3, 3),
  ('60000000-0000-0003-0000-000000000003', '50000000-0000-0000-0000-000000000003', '2026-08-20T18:00:00+09:00', '2026-08-20T19:00:00+09:00', 3, 52, '{"availability":50,"required":50}', 2, 2),
  ('60000000-0000-0004-0000-000000000001', '50000000-0000-0000-0000-000000000004', '2026-08-29T15:00:00+09:00', '2026-08-29T17:00:00+09:00', 1, 93, '{"availability":100,"weekend":85}', 4, 3),
  ('60000000-0000-0004-0000-000000000002', '50000000-0000-0000-0000-000000000004', '2026-08-29T13:00:00+09:00', '2026-08-29T15:00:00+09:00', 2, 48, '{"availability":50,"required":33}', 2, 1),
  ('60000000-0000-0005-0000-000000000001', '50000000-0000-0000-0000-000000000005', '2026-08-21T19:00:00+09:00', '2026-08-21T20:00:00+09:00', 1, 89, '{"availability":83,"required":100,"fairness":95}', 5, 3),
  ('60000000-0000-0005-0000-000000000002', '50000000-0000-0000-0000-000000000005', '2026-08-21T18:00:00+09:00', '2026-08-21T19:00:00+09:00', 2, 76, '{"availability":83,"required":67,"fairness":55}', 5, 2),
  ('60000000-0000-0006-0000-000000000001', '50000000-0000-0000-0000-000000000006', '2026-08-27T17:30:00+09:00', '2026-08-27T19:00:00+09:00', 1, 96, '{"availability":100,"required":100}', 6, 3),
  ('60000000-0000-0006-0000-000000000002', '50000000-0000-0000-0000-000000000006', '2026-08-26T19:30:00+09:00', '2026-08-26T21:00:00+09:00', 2, 64, '{"availability":67,"required":67}', 4, 2),
  ('60000000-0000-0006-0000-000000000003', '50000000-0000-0000-0000-000000000006', '2026-08-26T18:00:00+09:00', '2026-08-26T19:30:00+09:00', 3, 59, '{"availability":67,"required":33}', 4, 1),
  ('60000000-0000-0007-0000-000000000001', '50000000-0000-0000-0000-000000000007', '2026-08-23T18:00:00+09:00', '2026-08-23T19:00:00+09:00', 1, 95, '{"availability":100,"required":100}', 5, 2),
  ('60000000-0000-0007-0000-000000000002', '50000000-0000-0000-0000-000000000007', '2026-08-22T18:00:00+09:00', '2026-08-22T19:00:00+09:00', 2, 69, '{"availability":60,"required":100}', 3, 2),
  ('60000000-0000-0007-0000-000000000003', '50000000-0000-0000-0000-000000000007', '2026-08-22T19:00:00+09:00', '2026-08-22T20:00:00+09:00', 3, 67, '{"availability":80,"required":50}', 4, 1)
on conflict (request_id, rank) do update
set starts_at = excluded.starts_at, ends_at = excluded.ends_at,
    score = excluded.score, score_breakdown = excluded.score_breakdown,
    available_count = excluded.available_count,
    required_available_count = excluded.required_available_count;

-- Store one availability row per requested participant and candidate. The busy
-- map below is the explicit expected result of intersecting candidates with the
-- seeded calendar_busy_blocks.
with busy_map(candidate_id, user_id) as (values
  ('60000000-0000-0001-0000-000000000002'::uuid, '10000000-0000-0000-0000-000000000005'::uuid),
  ('60000000-0000-0001-0000-000000000003', '10000000-0000-0000-0000-000000000003'),
  ('60000000-0000-0001-0000-000000000003', '10000000-0000-0000-0000-000000000004'),
  ('60000000-0000-0003-0000-000000000002', '10000000-0000-0000-0000-000000000001'),
  ('60000000-0000-0003-0000-000000000003', '10000000-0000-0000-0000-000000000002'),
  ('60000000-0000-0003-0000-000000000003', '10000000-0000-0000-0000-000000000006'),
  ('60000000-0000-0004-0000-000000000002', '10000000-0000-0000-0000-000000000004'),
  ('60000000-0000-0004-0000-000000000002', '10000000-0000-0000-0000-000000000006'),
  ('60000000-0000-0005-0000-000000000001', '10000000-0000-0000-0000-000000000005'),
  ('60000000-0000-0005-0000-000000000002', '10000000-0000-0000-0000-000000000007'),
  ('60000000-0000-0006-0000-000000000002', '10000000-0000-0000-0000-000000000005'),
  ('60000000-0000-0006-0000-000000000002', '10000000-0000-0000-0000-000000000006'),
  ('60000000-0000-0006-0000-000000000003', '10000000-0000-0000-0000-000000000005'),
  ('60000000-0000-0006-0000-000000000003', '10000000-0000-0000-0000-000000000007'),
  ('60000000-0000-0007-0000-000000000002', '10000000-0000-0000-0000-000000000003'),
  ('60000000-0000-0007-0000-000000000002', '10000000-0000-0000-0000-000000000008'),
  ('60000000-0000-0007-0000-000000000003', '10000000-0000-0000-0000-000000000007')
)
insert into public.candidate_availability (
  candidate_id, user_id, availability, reason_code
)
select
  c.id,
  p.user_id,
  case when b.user_id is null then 'available'::public.slot_availability
       else 'busy'::public.slot_availability end,
  case when b.user_id is null then null else 'calendar_busy_block' end
from public.schedule_candidates c
join public.meeting_request_participants p on p.request_id = c.request_id
left join busy_map b on b.candidate_id = c.id and b.user_id = p.user_id
where c.request_id in (
  '50000000-0000-0000-0000-000000000001',
  '50000000-0000-0000-0000-000000000003',
  '50000000-0000-0000-0000-000000000004',
  '50000000-0000-0000-0000-000000000005',
  '50000000-0000-0000-0000-000000000006',
  '50000000-0000-0000-0000-000000000007'
)
on conflict (candidate_id, user_id) do update
set availability = excluded.availability, reason_code = excluded.reason_code;

-- ---------------------------------------------------------------------------
-- Historical and confirmed meetings
-- ---------------------------------------------------------------------------

insert into public.meetings (
  id, group_id, source_request_id, created_by, title,
  starts_at, ends_at, status, context
)
values
  ('70000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000003', null, '10000000-0000-0000-0000-000000000003', '동아리 8월 1차 운영회의', '2026-08-03T19:00:00+09:00', '2026-08-03T20:00:00+09:00', 'held', '{"seed":"attendance_history"}'),
  ('70000000-0000-0000-0000-000000000002', '30000000-0000-0000-0000-000000000003', null, '10000000-0000-0000-0000-000000000003', '행사 준비 점검', '2026-08-07T18:30:00+09:00', '2026-08-07T19:30:00+09:00', 'held', '{"seed":"attendance_history"}'),
  ('70000000-0000-0000-0000-000000000003', '30000000-0000-0000-0000-000000000003', null, '10000000-0000-0000-0000-000000000003', '동아리 8월 2차 운영회의', '2026-08-12T19:00:00+09:00', '2026-08-12T20:00:00+09:00', 'held', '{"seed":"attendance_history"}'),
  ('70000000-0000-0000-0000-000000000004', '30000000-0000-0000-0000-000000000002', '50000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000002', '캡스톤 주간 스터디', '2026-08-20T20:00:00+09:00', '2026-08-20T21:00:00+09:00', 'confirmed', '{"selected_candidate_rank":1}'),
  ('70000000-0000-0000-0000-000000000005', '30000000-0000-0000-0000-000000000001', '50000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'AI 데모 기능 점검', '2026-08-18T14:00:00+09:00', '2026-08-18T15:00:00+09:00', 'confirmed', '{"selected_candidate_rank":1}')
on conflict (id) do update
set group_id = excluded.group_id, source_request_id = excluded.source_request_id,
    created_by = excluded.created_by, title = excluded.title,
    starts_at = excluded.starts_at, ends_at = excluded.ends_at,
    status = excluded.status, context = excluded.context, updated_at = now();

with attendance(meeting_no, user_no, is_required, rsvp, attendance, note, recorded_at) as (values
  (1,2,false,'accepted','attended',null,'2026-08-03T20:05:00+09:00'::timestamptz),
  (1,3,true, 'accepted','attended',null,'2026-08-03T20:05:00+09:00'),
  (1,5,false,'accepted','attended',null,'2026-08-03T20:05:00+09:00'),
  (1,6,true, 'accepted','excused','개인 사정','2026-08-03T20:05:00+09:00'),
  (1,7,true, 'accepted','no_show','사전 연락 없음','2026-08-03T20:05:00+09:00'),
  (1,8,false,'accepted','attended',null,'2026-08-03T20:05:00+09:00'),
  (2,2,false,'accepted','attended',null,'2026-08-07T19:35:00+09:00'),
  (2,3,true, 'accepted','attended',null,'2026-08-07T19:35:00+09:00'),
  (2,5,false,'accepted','attended',null,'2026-08-07T19:35:00+09:00'),
  (2,6,true, 'accepted','attended',null,'2026-08-07T19:35:00+09:00'),
  (2,7,true, 'accepted','no_show','사전 연락 없음','2026-08-07T19:35:00+09:00'),
  (2,8,false,'tentative','excused','학교 일정','2026-08-07T19:35:00+09:00'),
  (3,2,false,'accepted','attended',null,'2026-08-12T20:05:00+09:00'),
  (3,3,true, 'accepted','attended',null,'2026-08-12T20:05:00+09:00'),
  (3,5,false,'accepted','attended',null,'2026-08-12T20:05:00+09:00'),
  (3,6,true, 'accepted','attended',null,'2026-08-12T20:05:00+09:00'),
  (3,7,true, 'accepted','attended',null,'2026-08-12T20:05:00+09:00'),
  (3,8,false,'accepted','attended',null,'2026-08-12T20:05:00+09:00'),
  (4,1,true, 'accepted','unknown',null,null),
  (4,2,true, 'accepted','unknown',null,null),
  (4,4,true, 'accepted','unknown',null,null),
  (4,6,true, 'accepted','unknown',null,null),
  (5,1,true, 'accepted','unknown',null,null),
  (5,2,true, 'accepted','unknown',null,null),
  (5,3,true, 'accepted','unknown',null,null),
  (5,4,false,'accepted','unknown',null,null),
  (5,5,false,'tentative','unknown',null,null)
)
insert into public.meeting_participants (
  meeting_id, user_id, is_required, rsvp_status, attendance_status,
  attendance_note, attendance_recorded_at
)
select
  ('70000000-0000-0000-0000-' || lpad(meeting_no::text, 12, '0'))::uuid,
  ('10000000-0000-0000-0000-' || lpad(user_no::text, 12, '0'))::uuid,
  is_required,
  rsvp::public.rsvp_status,
  attendance::public.attendance_status,
  note,
  recorded_at
from attendance
on conflict (meeting_id, user_id) do update
set is_required = excluded.is_required,
    rsvp_status = excluded.rsvp_status,
    attendance_status = excluded.attendance_status,
    attendance_note = excluded.attendance_note,
    attendance_recorded_at = excluded.attendance_recorded_at;

-- Past report snapshots make weekly report listing and read state testable.
insert into public.weekly_reports (
  id, user_id, week_start, delivery_channel, delivery_status,
  content, ai_summary, generated_at, read_at
)
values
  ('80000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000002', '2026-08-03', 'web', 'read', '{"held_meetings":2,"attended":2,"no_show":0}', '이번 주 모든 운영 회의에 참석했습니다.', '2026-08-10T08:00:00+09:00', '2026-08-10T09:00:00+09:00'),
  ('80000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000007', '2026-08-03', 'web', 'ready', '{"held_meetings":2,"attended":0,"no_show":2}', '최근 불참이 이어졌습니다. 다음 회의는 참석 가능한 후보를 우선 확인해 주세요.', '2026-08-10T08:00:00+09:00', null),
  ('80000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000002', '2026-08-10', 'web', 'ready', '{"held_meetings":1,"attended":1,"no_show":0}', '이번 주 운영 회의에도 참석했습니다.', '2026-08-17T08:00:00+09:00', null)
on conflict (user_id, week_start) do update
set delivery_channel = excluded.delivery_channel,
    delivery_status = excluded.delivery_status,
    content = excluded.content,
    ai_summary = excluded.ai_summary,
    generated_at = excluded.generated_at,
    read_at = excluded.read_at;

commit;
